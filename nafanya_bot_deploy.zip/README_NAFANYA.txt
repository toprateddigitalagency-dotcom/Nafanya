
НАФАНЯ ЯДРО v2 — Полностью Автоматическое

Файлы и папки:
- Gemini/gemini_api_key.txt — ключ для Gemini
- Binance/binance_config.json — ключи Binance
- nafany_config.json — главный конфиг системы
- nafany_log.txt — все события ядра
- NaFanya_Core.ipynb — сам блокнот ядра

Изменение конфигурации:
- Меняй настройки прямо в nafany_config.json на Google Диске
- Ключи Gemini и Binance правь в своих файлах
- Перезапусти ядро для применения изменений

Функции ядра:
- Автопроверка модулей Gemini и Binance
- Отображение статуса и баланса Binance
- Логирование всех действий
- Полностью автоматический режим — без команд
